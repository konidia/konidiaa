import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk
import pytesseract

class TextExtractorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Text Extractor")

        self.image_path = ""
        self.extracted_text = ""

        # Membuat GUI
        self.create_gui()

    def create_gui(self):
        # Tombol untuk memilih file gambar
        self.choose_button = tk.Button(self.root, text="Pilih Gambar", command=self.choose_image)
        self.choose_button.pack(pady=20)

        # Menampilkan gambar yang dipilih
        self.image_label = tk.Label(self.root)
        self.image_label.pack()

        # Tombol untuk mengekstrak teks
        self.extract_button = tk.Button(self.root, text="Ekstrak Teks", command=self.extract_text)
        self.extract_button.pack(pady=10)

        # Menampilkan teks yang diekstrak
        self.text_label = tk.Label(self.root, text="")
        self.text_label.pack(pady=20)

    def choose_image(self):
        self.image_path = filedialog.askopenfilename(filetypes=[("Image Files", "*.png;*.jpg;*.jpeg;*.gif")])

        if self.image_path:
            # Menampilkan gambar yang dipilih
            image = Image.open(self.image_path)
            image = image.resize((300, 300), Image.ANTIALIAS)
            photo = ImageTk.PhotoImage(image)
            self.image_label.config(image=photo)
            self.image_label.image = photo

    def extract_text(self):
        if self.image_path:
            # Menggunakan pytesseract untuk mengekstrak teks dari gambar
            try:
                extracted_text = pytesseract.image_to_string(Image.open(self.image_path))
                self.extracted_text = extracted_text
                self.text_label.config(text=f"Teks yang diekstrak:\n{extracted_text}")
            except Exception as e:
                self.text_label.config(text="Error dalam mengekstrak teks. Pastikan Tesseract OCR telah terinstal.")

if __name__ == "__main__":
    root = tk.Tk()
    app = TextExtractorApp(root)
    root.mainloop()
