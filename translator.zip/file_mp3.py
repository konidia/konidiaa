import os
import tkinter as tk
from tkinter import filedialog
import pygame

class MusicPlayer:
    def __init__(self, root):
        self.root = root
        self.root.title("MP3 Player")

        self.current_file = ""
        self.paused = False

        # Membuat GUI
        self.create_gui()

    def create_gui(self):
        # Tombol untuk memilih file MP3
        self.choose_button = tk.Button(self.root, text="Pilih File MP3", command=self.choose_file)
        self.choose_button.pack(pady=20)

        # Tombol play
        self.play_button = tk.Button(self.root, text="Play", command=self.play_music)
        self.play_button.pack(pady=10)

        # Tombol pause/resume
        self.pause_button = tk.Button(self.root, text="Pause", command=self.pause_resume_music)
        self.pause_button.pack(pady=10)

        # Tombol stop
        self.stop_button = tk.Button(self.root, text="Stop", command=self.stop_music)
        self.stop_button.pack(pady=10)

        # Inisialisasi Pygame
        pygame.init()

    def choose_file(self):
        self.current_file = filedialog.askopenfilename(defaultextension=".mp3", filetypes=[("MP3 Files", "*.mp3")])

    def play_music(self):
        if self.current_file:
            if not pygame.mixer.music.get_busy() or self.paused:
                pygame.mixer.music.load(self.current_file)
                pygame.mixer.music.play()
                self.paused = False

    def pause_resume_music(self):
        if pygame.mixer.music.get_busy():
            if not self.paused:
                pygame.mixer.music.pause()
                self.paused = True
            else:
                pygame.mixer.music.unpause()
                self.paused = False

    def stop_music(self):
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.stop()

if __name__ == "__main__":
    root = tk.Tk()
    player = MusicPlayer(root)
    root.mainloop()
