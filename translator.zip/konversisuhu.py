import tkinter as tk

def konversi_suhu():
    try:
        suhu_awal = float(entry_suhu.get())
        suhu_awal_satuan = combo_suhu_awal.get()
        suhu_tujuan_satuan = combo_suhu_tujuan.get()

        if suhu_awal_satuan == 'Celsius':
            if suhu_tujuan_satuan == 'Fahrenheit':
                suhu_tujuan = (suhu_awal * 9/5) + 32
            elif suhu_tujuan_satuan == 'Reamur':
                suhu_tujuan = suhu_awal * 4/5
            elif suhu_tujuan_satuan == 'Kelvin':
                suhu_tujuan = suhu_awal + 273.15
            else:
                suhu_tujuan = suhu_awal

        elif suhu_awal_satuan == 'Fahrenheit':
            if suhu_tujuan_satuan == 'Celsius':
                suhu_tujuan = (suhu_awal - 32) * 5/9
            elif suhu_tujuan_satuan == 'Reamur':
                suhu_tujuan = (suhu_awal - 32) * 5/9 * 4/5
            elif suhu_tujuan_satuan == 'Kelvin':
                suhu_tujuan = (suhu_awal - 32) * 5/9 + 273.15
            else:
                suhu_tujuan = suhu_awal

        elif suhu_awal_satuan == 'Reamur':
            if suhu_tujuan_satuan == 'Celsius':
                suhu_tujuan = suhu_awal * 5/4
            elif suhu_tujuan_satuan == 'Fahrenheit':
                suhu_tujuan = suhu_awal * 9/4 + 32
            elif suhu_tujuan_satuan == 'Kelvin':
                suhu_tujuan = suhu_awal * 5/4 + 273.15
            else:
                suhu_tujuan = suhu_awal

        elif suhu_awal_satuan == 'Kelvin':
            if suhu_tujuan_satuan == 'Celsius':
                suhu_tujuan = suhu_awal - 273.15
            elif suhu_tujuan_satuan == 'Fahrenheit':
                suhu_tujuan = (suhu_awal - 273.15) * 9/5 + 32
            elif suhu_tujuan_satuan == 'Reamur':
                suhu_tujuan = (suhu_awal - 273.15) * 4/5
            else:
                suhu_tujuan = suhu_awal

        else:
            suhu_tujuan = suhu_awal

        label_hasil.config(text=f"Hasil: {suhu_tujuan:.2f} {suhu_tujuan_satuan}")

    except ValueError:
        label_hasil.config(text="Masukkan suhu dengan benar.")

# Membuat GUI
root = tk.Tk()
root.title("Konverter Suhu")

# Label dan Entry untuk suhu awal
label_suhu_awal = tk.Label(root, text="Suhu Awal:")
label_suhu_awal.grid(row=0, column=0, padx=10, pady=10)
entry_suhu = tk.Entry(root)
entry_suhu.grid(row=0, column=1, padx=10, pady=10)

# Combobox untuk satuan suhu awal
satuan_suhu = ['Celsius', 'Fahrenheit', 'Reamur', 'Kelvin']
combo_suhu_awal = tk.StringVar()
combo_suhu_awal.set(satuan_suhu[0])
menu_suhu_awal = tk.OptionMenu(root, combo_suhu_awal, *satuan_suhu)
menu_suhu_awal.grid(row=0, column=2, padx=10, pady=10)

# Label untuk tanda samadengan dan hasil
label_tanda_samadengan = tk.Label(root, text="=")
label_tanda_samadengan.grid(row=0, column=3, padx=10, pady=10)
label_hasil = tk.Label(root, text="Hasil:")
label_hasil.grid(row=0, column=4, padx=10, pady=10)

# Combobox untuk satuan suhu tujuan
combo_suhu_tujuan = tk.StringVar()
combo_suhu_tujuan.set(satuan_suhu[1])
menu_suhu_tujuan = tk.OptionMenu(root, combo_suhu_tujuan, *satuan_suhu)
menu_suhu_tujuan.grid(row=0, column=5, padx=10, pady=10)

# Tombol konversi
tombol_konversi = tk.Button(root, text="Konversi", command=konversi_suhu)
tombol_konversi.grid(row=0, column=6, padx=10, pady=10)

# Menjalankan program
root.mainloop()
